package com.demo.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.demo.connection.DBconnection;
import com.demo.model.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/logFomr")
public class Login extends HttpServlet{

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		
		String username = req.getParameter("username");
		String email  = req.getParameter("email");
		
		try {
			
			Connection con = DBconnection.getConnection();
			
			PreparedStatement ps1 = con.prepareStatement("select * from userInfo where name=? and email=?");
			
			ps1.setString(1, username);
			ps1.setString(2,email);
			
			PreparedStatement ps2 = con.prepareStatement("select * from admin where name=? and email=?");
			
			ps2.setString(1, username);
			ps2.setString(2, email);
//			
			ResultSet rs1 = ps1.executeQuery();
			ResultSet rs2 = ps2.executeQuery();
			
			if(rs1.next()) {
				User user = new User();
				
				user.setName(rs1.getString("name"));
				user.setId(rs1.getInt("id"));
				user.setEmail(rs1.getString("email"));
				user.setCity(rs1.getString("city"));
				
				HttpSession session = req.getSession();
				session.setAttribute("session_user", user);
				
				RequestDispatcher rd = req.getRequestDispatcher("profile.jsp");
				rd.include(req, resp);
			}
			else if(rs2.next()) {
				RequestDispatcher rd = req.getRequestDispatcher("admin.jsp");
				rd.forward(req, resp);
			}
			else {
				resp.setContentType("text/html");
				out.println("<h3 style='color:red'>Username or passwrod incorrect</h3>");
				
				RequestDispatcher rd = req.getRequestDispatcher("Login.html");
				rd.include(req, resp);
			}
		}
		catch (Exception e) {
			resp.setContentType("text/html");
			out.println("<h3 style='color:red'>Exception occur: "+e.getMessage()+"</h3>");
			
			RequestDispatcher rd = req.getRequestDispatcher("Login.html");
			rd.include(req, resp);
		}
		
		
	}
	
}
