package com.demo.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.demo.connection.DBconnection;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/regForm")
public class Register extends HttpServlet{

	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		
		String name = req.getParameter("name");
		int id = Integer.parseInt(req.getParameter("id"));
		String email = req.getParameter("email");
		String city = req.getParameter("city");
		
		try {
			Connection con = DBconnection.getConnection();
			
			if(con == null) {
				resp.setContentType("text/html");
				out.println("<h3 style='color:red'>Error occur: Unable to connect to the database</h3>");
				
				RequestDispatcher rd = req.getRequestDispatcher("Register.html");
				rd.include(req, resp);
				return;
			}
			
			PreparedStatement ps = con.prepareStatement("insert into userInfo(name, id, email, city) values(?,?,?,?)");
			
			ps.setString(1, name);
			ps.setInt(2, id);
			ps.setString(3, email);
			ps.setString(4, city);
			
			int rowEffected = ps.executeUpdate();
			
			if(rowEffected>0) {
				resp.setContentType("text/html");
				out.println("<h3 style='color:green'>Registration successful</h3>");
				
				RequestDispatcher rd = req.getRequestDispatcher("Register.html");
				rd.include(req, resp);
				
			}
			else {
				resp.setContentType("text/html");
				out.println("<h3 style='color:red'>Registration failed</h3>");
				
				RequestDispatcher rd = req.getRequestDispatcher("Register.html");
				rd.include(req, resp);
			}
		}
		catch(Exception e) {
			resp.setContentType("text/html");
			out.println("<h3 style='color:red'>Error occur: "+e.getMessage()+"</h3>");
			
			RequestDispatcher rd = req.getRequestDispatcher("Register.html");
			rd.include(req, resp);
		}
		
	}
	
}