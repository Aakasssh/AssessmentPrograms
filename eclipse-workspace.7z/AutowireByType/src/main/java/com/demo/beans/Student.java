package com.demo.beans;

public class Student {
	
	private String name;
	private int id;
	private Address address;
	
	public Student() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public void display() {
		System.out.println("Student name: "+name);
		System.out.println("Student rollNo: "+id);
		System.out.println("Student address: "+address);
	}
	
}
