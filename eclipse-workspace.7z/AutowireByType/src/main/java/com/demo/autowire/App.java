package com.demo.autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.Student;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        String contxtLoc = "/com/demo/resource/applicationContext.xml";
        
        ApplicationContext context = new ClassPathXmlApplicationContext(contxtLoc);
        
        Student std = (Student) context.getBean("std",Student.class);
        
        std.display();
    }
}
