package com.demo.crud.dao;

import java.util.List;

import com.demo.crud.Student;

public interface StudentDaao {

	public int insert(Student student);
	
	public int update(Student student);
//	
	public int delete(Student student);
//	
	public List<Student> read();
}
