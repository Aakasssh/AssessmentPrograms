package com.demo.crud.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.demo.crud.Student;

public class StudentRowMapper implements RowMapper<Student>{
	
	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		
		Student std = new Student();
		
		std.setName(rs.getString("name1"));
		std.setEmail(rs.getString("email"));
		std.setPass(rs.getString("pass"));
		std.setCity(rs.getString("city"));
		
		return std;
	}
	
}
