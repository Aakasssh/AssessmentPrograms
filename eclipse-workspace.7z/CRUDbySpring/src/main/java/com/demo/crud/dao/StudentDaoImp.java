package com.demo.crud.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.demo.crud.Student;

public class StudentDaoImp implements StudentDaao{

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int insert(Student student) {
		
		String insertQuery = "insert into registerTable(name1,email,pass,city) values(?,?,?,?)";
		
		int result = this.jdbcTemplate.update(insertQuery,student.getName(),student.getEmail(),student.getPass(),student.getCity());
		
		return result;
		
	}
	
	public int update(Student student) {
		String updateQuery = "update registerTable set email=?, city=?, pass=? where name1=?";
		
		int result = this.jdbcTemplate.update(updateQuery,student.getEmail(),student.getCity(),student.getPass(),student.getName());
		
		return result;
	}
	
	public int delete(Student student) {
		String deleteQuery = "delete from registerTable where name1=?";
		
		int result = this.jdbcTemplate.update(deleteQuery,student.getName());
		
		return result;
	}
	
	public List<Student> read(){
		
		String readQuery = "select * from registerTable";
		
		List<Student> stdList = this.jdbcTemplate.query(readQuery, new StudentRowMapper());
		
		return stdList;
	}
}

