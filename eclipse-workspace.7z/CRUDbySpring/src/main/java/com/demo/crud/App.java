package com.demo.crud;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.crud.dao.StudentDaao;


public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        String contextLoc = "com/demo/resources/applicationContext.xml";
        
        ApplicationContext context = new ClassPathXmlApplicationContext(contextLoc);
        
        StudentDaao studentDaao = context.getBean("studentDao",StudentDaao.class);
        
        Student std = new Student();
//        std.setName("Roshan");
//        std.setEmail("roshani@gmail.com");
//        std.setCity("Loni");
//        std.setPass("123");
       
//        int rowExecuted = studentDaao.delete(std);
//        
//        if(rowExecuted>0) {
//        	System.out.println("data delete");
//        }
//        else {
//        	System.out.println("Data not delete");
//        	
//        	}
        
        List<Student> stdList = studentDaao.read();
        for(Student show: stdList) {
        	System.out.println(show);
        	System.out.println("<---------------------------------------------->");
        }
    }
}
