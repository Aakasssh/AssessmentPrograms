package com.demo.injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.beans.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	System.out.println("Hello World!");

		String contxtLoc = "com/demo/resource/applicationContext.xml";

		ApplicationContext context = new ClassPathXmlApplicationContext(contxtLoc);

		Employee emp = (Employee) context.getBean("emp");

		emp.display();
    }
}
