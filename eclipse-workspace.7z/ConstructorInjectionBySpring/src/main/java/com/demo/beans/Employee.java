package com.demo.beans;

import java.beans.ConstructorProperties;
import java.util.List;
import java.util.Map;

public class Employee {
	
	private String name;
	private List<String> skills;
	private Map<String, String> course;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	@ConstructorProperties({"name", "skills", "course"})
	public Employee(String name, List<String> skills, Map<String, String> course) {
		
		this.name = name;
		this.skills = skills;
		this.course = course;
	}

	public void display() {
		System.out.println("Employee name: "+name);
		System.out.println("Employee skills: "+skills);
		System.out.println("Employee course: "+course);
		
	}
}
