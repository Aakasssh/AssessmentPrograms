package com.demo.insert;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.dao.UserDao;
import com.demo.entities.User;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        String configLoc = "/com/demo/resource/ApplicationContext.xml";
        
        ApplicationContext context = new ClassPathXmlApplicationContext(configLoc);
        
        UserDao operation =  context.getBean("UserDao",UserDao.class);
        
        User user = new User();
        
        int result = operation.insert(user);
        
        if(result>0) {
        	System.out.println("Data insertion successful");
        }
        else {
        	System.out.println("Data insertion failed");
        }
        
    }
}
