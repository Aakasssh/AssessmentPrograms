package com.demo.dao;

import java.util.Scanner;

import org.springframework.jdbc.core.JdbcTemplate;

import com.demo.entities.User;

public class UserDaoImpl implements UserDao{
	
	Scanner sc = new Scanner(System.in);
	
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insert(User user) {
		
		System.out.print("Enter user name: ");
		user.setName(sc.next());
		
		System.out.print("Enter user id: ");
		user.setId(sc.nextInt());
		
		System.out.print("Enter user email: ");
		user.setEmail(sc.next());
		
		System.out.print("Enter user city: ");
		user.setCity(sc.next());
		
		String query = "insert into userInfo(name,id,email,city) values(?,?,?,?)";
		
		int result = this.jdbcTemplate.update(query,user.getName(),user.getId(),user.getEmail(),user.getCity());
		
		return result;
	}
	
}
