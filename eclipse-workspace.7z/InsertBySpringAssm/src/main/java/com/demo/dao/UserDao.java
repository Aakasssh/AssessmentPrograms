package com.demo.dao;

import com.demo.entities.User;

public interface UserDao {
	
	public int insert(User user);
	
}
