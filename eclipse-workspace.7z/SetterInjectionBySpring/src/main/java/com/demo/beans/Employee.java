package com.demo.beans;

import java.util.List;
import java.util.Map;

public class Employee {
	
	private String name;
	private List<String> skills;
	private Map<String, String> course;
	
	public Employee() {
	
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	public void setCourse(Map<String, String> course) {
		this.course = course;
	}
	
	public void display() {
		System.out.println("Employee name: "+name);
		System.out.println("Employee skills: "+skills);
		System.out.println("Employee course: "+course);
		
	}
}
